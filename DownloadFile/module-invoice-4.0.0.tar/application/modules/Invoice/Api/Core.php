<?php 



class Invoice_Api_Core extends Core_Api_Abstract
{
  
}



?>