<?php 





return array(
    array(
        'title' => 'Invoices Search',
        'description' => 'Displays a search form in the invoice browse page.',
        'category' => 'Invoices',
        'type' => 'widget',
        'name' => 'invoice.browse-search',
        'requirements' => array(
            'no-subject',
        ),
    ),


);






?>