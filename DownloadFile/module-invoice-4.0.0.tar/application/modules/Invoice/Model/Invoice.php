<?php 



class Invoice_Model_Invoice extends Core_Model_Item_Abstract{


	public function getHref($params = array()){

      
	}
	
}




?>