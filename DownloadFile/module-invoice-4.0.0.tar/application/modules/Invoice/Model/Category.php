<?php



class Invoice_Model_Category extends Core_Model_Item_Abstract{

}



?>