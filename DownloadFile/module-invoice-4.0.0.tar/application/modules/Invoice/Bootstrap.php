<?php

class Invoice_Bootstrap extends Engine_Application_Bootstrap_Abstract
{

}